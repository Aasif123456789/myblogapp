package com.myblog.myblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyblogappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyblogappApplication.class, args);
	}

}
